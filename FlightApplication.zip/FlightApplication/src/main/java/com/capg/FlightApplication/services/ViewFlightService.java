package com.capg.FlightApplication.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.FlightApplication.DAO.ViewFlightDAOImpl;
import com.capg.FlightApplication.entities.ViewFlight;

@Service
public class ViewFlightService {
	
	@Autowired
	ViewFlightDAOImpl dao;
	
	public List<ViewFlight> getAllFlights(){
		return dao.getAllFlights();
	}

}
