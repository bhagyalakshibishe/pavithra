package com.capg.FlightApplication.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.FlightApplication.entities.User;

@Repository
public class UserDAOImpl implements UserDAO{
	
	@Autowired
	UserRepo repo;
	
	@Override
	public List<User> getAllUsers() {
		return repo.findAll();
	}

}
