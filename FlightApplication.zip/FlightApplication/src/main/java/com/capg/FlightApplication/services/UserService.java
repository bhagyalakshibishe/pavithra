package com.capg.FlightApplication.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.capg.FlightApplication.DAO.UserDAOImpl;
import com.capg.FlightApplication.entities.User;

public class UserService {
	
	@Autowired
	UserDAOImpl dao;
	
	public List<User> getAllUsers() {
		return dao.getAllUsers();
	}

}
