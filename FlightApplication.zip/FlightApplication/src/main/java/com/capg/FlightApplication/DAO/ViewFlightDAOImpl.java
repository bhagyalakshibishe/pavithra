package com.capg.FlightApplication.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.FlightApplication.entities.ViewFlight;


@Repository
public class ViewFlightDAOImpl implements ViewFlightDAO{
	
	@Autowired
	ViewFlightRepo repo;

	@Override
	public List<ViewFlight> getAllFlights() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
