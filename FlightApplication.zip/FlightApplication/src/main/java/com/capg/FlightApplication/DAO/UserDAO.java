package com.capg.FlightApplication.DAO;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.capg.FlightApplication.entities.User;


@Repository
public interface UserDAO {
	
	public List<User> getAllUsers();

}
