package com.capg.FlightApplication.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import com.capg.FlightApplication.entities.User;
import com.capg.FlightApplication.services.UserService;

public class UserController {
	
	@Autowired
	UserService uservice;
	
	@GetMapping(path="/users")
	public List<User> getAllUsers(){
		return uservice.getAllUsers();
	}

}
