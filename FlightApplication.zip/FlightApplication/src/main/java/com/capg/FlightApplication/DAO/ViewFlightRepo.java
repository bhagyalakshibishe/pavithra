package com.capg.FlightApplication.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.capg.FlightApplication.entities.ViewFlight;

@RepositoryRestResource
public interface ViewFlightRepo extends JpaRepository<ViewFlight, Integer>{

}
