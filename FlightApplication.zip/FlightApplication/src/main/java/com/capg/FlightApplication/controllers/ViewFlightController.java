package com.capg.FlightApplication.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.FlightApplication.entities.User;
import com.capg.FlightApplication.entities.ViewFlight;
import com.capg.FlightApplication.services.UserService;
import com.capg.FlightApplication.services.ViewFlightService;


@RestController
@CrossOrigin
public class ViewFlightController {
	
	@Autowired
	ViewFlightService service;
	
	
	@GetMapping(path="/flights")
	public List<ViewFlight> getAllFlights(){
		return service.getAllFlights();
	}
	
	

}
