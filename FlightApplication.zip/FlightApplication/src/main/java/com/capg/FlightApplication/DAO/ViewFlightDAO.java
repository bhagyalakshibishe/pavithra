package com.capg.FlightApplication.DAO;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.capg.FlightApplication.entities.ViewFlight;

@Repository
public interface ViewFlightDAO {
	
	public List<ViewFlight> getAllFlights();
	public List<ViewFlight> findFlights();
	

}
