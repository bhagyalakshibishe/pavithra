package com.capg.FlightApplication.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.data.rest.core.annotation.RestResource;


@Entity
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int RegisterNo;
	private String name;
	private String password;
	private String email;
	private String moblieNumber;
	private String gender;
	private Date date;
	
	@OneToMany(cascade= CascadeType.ALL)
	@RestResource(path="viewFlights", rel="flightId")
	private List<ViewFlight> flightDetails;
	
	public User(String name, String password, String email, String moblieNumber, String gender, Date date,
			List<ViewFlight> flightDetails) {
		super();
		this.name = name;
		this.password = password;
		this.email = email;
		this.moblieNumber = moblieNumber;
		this.gender = gender;
		this.date = date;
		this.flightDetails = flightDetails;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getRegisterNo() {
		return RegisterNo;
	}
	public void setRegisterNo(int registerNo) {
		RegisterNo = registerNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMoblieNumber() {
		return moblieNumber;
	}
	public void setMoblieNumber(String moblieNumber) {
		this.moblieNumber = moblieNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public List<ViewFlight> getFlightDetails() {
		return flightDetails;
	}
	public void setFlightDetails(List<ViewFlight> flightDetails) {
		this.flightDetails = flightDetails;
	}
	@Override
	public String toString() {
		return "User [RegisterNo=" + RegisterNo + ", name=" + name + ", password=" + password + ", email=" + email
				+ ", moblieNumber=" + moblieNumber + ", gender=" + gender + ", date=" + date + ", flightDetails="
				+ flightDetails + "]";
	}
	

}
