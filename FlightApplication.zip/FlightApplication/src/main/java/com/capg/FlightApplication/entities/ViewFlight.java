package com.capg.FlightApplication.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class ViewFlight {
	
	@Id
	private int flightId;
	private String origin;
	private String destination;
	private int noOfSeats;
	private double fare;
	
	@OneToMany(mappedBy="flightDetails")
	List<User> user;
	
	public ViewFlight() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public ViewFlight(int flightId, String origin, String destination, int noOfSeats, double fare, List<User> user) {
		super();
		this.flightId = flightId;
		this.origin = origin;
		this.destination = destination;
		this.noOfSeats = noOfSeats;
		this.fare = fare;
		this.user = user;
	}



	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public double getFare() {
		return fare;
	}

	public void setFare(double fare) {
		this.fare = fare;
	}

	
	
	public List<User> getUser() {
		return user;
	}



	public void setUser(List<User> user) {
		this.user = user;
	}



	@Override
	public String toString() {
		return "ViewFlight [flightId=" + flightId + ", origin=" + origin + ", destination=" + destination
				+ ", noOfSeats=" + noOfSeats + ", fare=" + fare + ", user=" + user + "]";
	}


}
